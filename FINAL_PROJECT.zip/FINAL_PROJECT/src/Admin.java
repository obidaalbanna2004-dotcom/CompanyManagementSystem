import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class Admin implements tasks {
    /****************************************************************************************** */
    static ArrayList<Manager> managers = new ArrayList<Manager>();
    static ArrayList<HolidayReq> HolidayReqs = new ArrayList<HolidayReq>();
    static File managerData = new File("Managers.data");
    static File holidays = new File("Holidays.data");
    ArrayList<HolidayReq> tempLed = new ArrayList<HolidayReq>();
    String id, Name, Password, Email, phoneNumber, temp, tempID;
    int stat = -1, i, ind, stars = 29;
    boolean status, found, correct, mangFound, done = false;

    /********************************************************************************************* */
    Admin() {
        read();
    }

    /********************************************************************************************* */
    public void adminInterfaces() {
        Main.repeat = true;
        System.out.println("*               |  Admin |               *");
        System.out.println("*********************************************");
        System.out.println("* 1- Add Manager.                           *");
        System.out.println("* 2- Update Password Manager.                         *");
        System.out.println("* 3- Delete Manager.                        *");
        System.out.println("* 4- Search about Manager.                  *");
        System.out.println("* 5- Report about Manager.                  *");
        System.out.println("* 6- Report All Managers.                   *");
        System.out.println("* 7- Holiday request.                       *");
        System.out.println("* 8- Deactivate & Activate Manager.         *");
        System.out.println("* 9- Get Manager count and Employee count.  *");
        System.out.println("* 10- Exit                                  *");
        System.out.println("**********************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("**********************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                addSomeone();
                break;
            case 2:
                Main.choice = -1;
                updateSomeone();
                break;
            case 3:
                Main.choice = -1;
                deleteSomeone();
                break;
            case 4:
                Main.choice = -1;
                searchSomeone();
                break;
            case 5:
                Main.choice = -1;
                reportAboutSomeone();
                break;
            case 6:
                Main.choice = -1;
                reportAll();
                break;
            case 7:
                Main.choice = -1;
                Main.repeat = true;
                while (Main.repeat) {
                    holidayRequests();
                }
                Main.repeat = true;
                break;
            case 8:
                Main.choice = -1;
                Main.repeat = true;
                while (Main.repeat) {
                    deactivateAndActivate();
                }
                Main.repeat = true;
                break;
            case 9:
                Main.choice = -1;
                System.out.println("*  | Get Manager count and Employee count |  *");
                System.out.println("**********************************************");
                System.out.println("* - Managers Count: " + managers.size() + "                        *");
                System.out.println("* - Employees Count: " + Manager.employees.size() + "                       *");
                System.out.println("**********************************************");
                break;
            case 10:
                Main.choice = -1;
                Main.repeat = false;
                break;

            default:
                System.out.println("*              Invalid Input             *");
                System.out.println("******************************************");
                break;
        }
    }

    /********************************************************************************************* */
    @Override
    public void addSomeone() {

        System.out.println("*            | Add Manager |             *");
        System.out.println("******************************************");
        System.out.print("* Enter ID: ");
        id = Main.input.nextLine();
        while (isIdTaken(id)) {
            System.out.println("******************************************");
            System.out.print("This ID is taken try anthor one: ");
            id = Main.input.nextLine();
        }
        System.out.println("******************************************");
        System.out.print("* Enter Name: ");
        Name = Main.input.nextLine();
        System.out.println("******************************************");
        System.out.print("* Enter Password: ");
        Password = Main.input.nextLine();
        System.out.println("******************************************");
        System.out.print("* Enter Phone Number: ");
        phoneNumber = Main.input.nextLine();
        System.out.println("******************************************");
        System.out.print("* Enter E-mail: ");
        Email = Main.input.nextLine();
        System.out.println("******************************************************");
        stat = -1;
        while (stat != 0 && stat != 1) {
            System.out.print("* Enter Manager Status: ");
            try {
                stat = Main.input.nextInt();
            } catch (InputMismatchException e) {
            }
            if (stat != 0 && stat != 1) {
                System.out.println("************************************");
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
            }
            Main.input.nextLine();
        }

        switch (stat) {
            case 1:
                status = true;
                managers.add(new Manager(id, Name, Password, phoneNumber, Email, status));
                write();
                System.out.println("******************************************");
                System.out.println("*       Manager Added Successfully       *");
                System.out.println("******************************************");
                break;
            case 0:
                status = false;
                managers.add(new Manager(id, Name, Password, phoneNumber, Email, status));
                write();
                System.out.println("******************************************");
                System.out.println("*       Manager Added Successfully       *");
                System.out.println("******************************************");
                break;
            default:
                System.out.println("******************************************");
                System.out.println("*            ! Invalid input !           *");
                System.out.println("******************************************");
                break;
        }
    }

    /********************************************************************************************* */
    @Override
    public void updateSomeone() {

        System.out.println("******************************************");
        System.out.println("*           | Update Password Manager |           *");
        System.out.println("******************************************");
        System.out.print("* Enter ID: ");
        temp = Main.input.nextLine();
        System.out.println("******************************************");
        for (Manager manager : managers) {
            if (manager.getId().equals(temp)) {
                System.out.print("* Enter new Password: ");
                manager.setPassword(Main.input.nextLine());
                done = true;
                break;
            }
        }
        if (done) {
            write();
            System.out.println("******************************************");
            System.out.println("*       Password have been updated       *");
            System.out.println("******************************************");
            done = false;
        } else {
            System.out.println("******************************************");
            System.out.println("*           Manager NOT FOUND!!          *");
            System.out.println("******************************************");
        }

    }

    /********************************************************************************************* */
    public static void write() {
        try {

            Main.oos = new ObjectOutputStream(new FileOutputStream(managerData));
            Main.oos.writeObject(managers);
            Main.oos.close();

        } catch (IOException e) {
        }
    }

    /********************************************************************************************* */
    public static void read() {
        try {
            Main.ois = new ObjectInputStream(new FileInputStream(managerData));
            managers = (ArrayList<Manager>) Main.ois.readObject();
            Main.ois.close();
        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
        }
    }

    /********************************************************************************************* */
    @Override
    public void deleteSomeone() {
        System.out.println("******************************************");
        System.out.println("*           | Delete Manager |           *");
        System.out.println("******************************************");
        temp = null;
        System.out.print("* Enter ID: ");
        temp = Main.input.nextLine();
        for (Manager manager : managers) {
            if (manager.getId().equals(temp)) {
                managers.remove(manager);
                done = true;
                write();
                break;
            }
        }
        if (done) {
            System.out.println("******************************************");
            System.out.println("*             Manager Deleted            *");
            System.out.println("******************************************");
            done = false;
        } else {
            System.out.println("******************************************");
            System.out.println("           Manager NOT FOUND!!           *");
            System.out.println("******************************************");
        }

    }

    /********************************************************************************************* */
    @Override
    public void searchSomeone() {
        System.out.println("******************************************");
        System.out.println("*        |  Search About Manager |       *");
        System.out.println("******************************************");
        String temp;
        System.out.print("* Enter ID: ");
        temp = Main.input.nextLine();
        for (Manager manager : managers) {
            if (manager.getId().equals(temp)) {
                stars += manager.getName().length();
                for (int i = 0; i < stars; i++) {
                    System.out.print("*");
                }
                System.out.println();
                System.out
                        .println("* " + manager.searchPerson() + "    *");
                done = true;
                break;
            }
        }
        if (done) {
            for (int i = 0; i < stars; i++) {
                System.out.print("*");
            }
            System.out.println();
            done = false;
        } else {
            System.out.println("******************************************");
            System.out.println("*           Manager NOT FOUND!!          *");
            System.out.println("******************************************");
        }

    }

    /********************************************************************************************* */
    @Override
    public void reportAboutSomeone() {
        System.out.println("******************************************");
        System.out.println("*         | Reort About Manager |        *");
        System.out.println("******************************************");
        String temp;
        System.out.print("* Enter ID or Name: ");
        temp = Main.input.nextLine();
        for (Manager manager : managers) {
            if (manager.getId().equals(temp) || manager.getName().equals(temp)) {
                for (int i = 0; i < manager.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println("* " + manager + "  *");
                for (int i = 0; i < manager.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                done = true;
            }
        }
        if (done) {
            done = false;
        } else {
            System.out.println("******************************************");
            System.out.println("*          Manager NOT FOUND!!           *");
            System.out.println("******************************************");
        }

    }

    /********************************************************************************************* */
    @Override
    public void reportAll() {
        System.out.println("*       | Reort About All Manager |      *");
        if (managers.size() > 0) {
            for (Manager manager : managers) {
                for (int i = 0; i < manager.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println("* " + manager + "  *");
            }
            for (int i = 0; i < managers.get(managers.size() - 1).toString().length() + 5; i++) {
                System.out.print('*');
            }
            System.out.println();
        } else {
            System.out.println("******************************************");
            System.out.println("*          No Managers FOUND!!           *");
            System.out.println("******************************************");
        }

    }

    /********************************************************************************************* */
    public void holidayRequests() {
        Main.repeat = true;
        System.out.println("*          | Holiday Requests |          *");
        System.out.println("******************************************");
        System.out.println("* 1- View Holiday requests.              *");
        System.out.println("* 2- Accept the holiday.                 *");
        System.out.println("* 3- Reject the holiday.                 *");
        System.out.println("* 4- Exit                                *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                viewRequests();

                break;
            case 2:
                Main.choice = -1;
                acceptHoliday();

                break;
            case 3:
                Main.choice = -1;
                rejectHoliday();
                break;
            case 4:
                Main.choice = -1;
                Main.repeat = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }
    }

    /********************************************************************************************* */
    public void viewRequests() {

        if (HolidayReqs.size() > 0) {
            for (HolidayReq holidayReq : HolidayReqs) {
                for (int i = 0; i < holidayReq.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println("* " + holidayReq + "  *");
                for (int i = 0; i < holidayReq.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
            }

        } else {
            System.out.println("******************************************");
            System.out.println("*       No Holiday Requests Found        *");
            System.out.println("******************************************");
        }
    }

    /********************************************************************************************* */
    public void acceptHoliday() {
        System.out.println("*           | Accept Holiday |           *");
        System.out.println("******************************************");
        if (HolidayReqs.size() > 0) {
            tempLed = new ArrayList<HolidayReq>();
            i = 0;
            ind = -1;
            found = false;
            correct = false;
            System.out.print("* Enter ID: ");
            tempID = Main.input.nextLine();
            for (HolidayReq holidayReq : HolidayReqs) {
                if (holidayReq.getId().equals(tempID) && holidayReq.getCheck() == -1) {
                    for (int j = 0; j < holidayReq.toString().length() + 5; j++) {
                        System.out.print('*');
                    }
                    System.out.println();
                    System.out.println((i + 1) + ": " + holidayReq);
                    for (int j = 0; j < holidayReq.toString().length() + 5; j++) {
                        System.out.print('*');
                    }
                    System.out.println();
                    i++;
                    tempLed.add(holidayReq);
                    found = true;
                }
            }
            if (found) {
                while (!correct) {
                    System.out.println("******************************************");
                    System.out.print("* Requist Number: ");
                    try {
                        ind = Main.input.nextInt();
                    } catch (InputMismatchException e) {
                        ind = -1;
                    }

                    Main.input.nextLine();
                    if (ind - 1 < 0 && ind - 1 > tempLed.size() - 1) {
                        System.out.println("******************************************");
                        System.out.println("*           Requsit not found            *");
                        System.out.println("******************************************");

                    } else {
                        correct = true;
                    }
                }
                tempLed.get(ind - 1).setCheck(1);
                find(tempID).holidayCount--;
                write();
                writeHolidays();
                System.out.println("******************************************");
                System.out.println("*           Requests Accepted            *");
                System.out.println("******************************************");
            } else {
                System.out.println("******************************************");
                System.out.println("* This employee has no Holiday Requests  *");
                System.out.println("******************************************");
            }

        } else {
            System.out.println("******************************************");
            System.out.println("*       No Holiday Requests Found        *");
            System.out.println("******************************************");
        }
    }

    /********************************************************************************************* */
    public void rejectHoliday() {
        System.out.println("*           | Reject Holiday |           *");
        System.out.println("******************************************");
        if (HolidayReqs.size() > 0) {
            tempLed = new ArrayList<HolidayReq>();
            String tempID;
            i = 0;
            ind = -1;
            found = false;
            correct = false;
            System.out.print("* Enter ID: ");
            tempID = Main.input.nextLine();
            for (HolidayReq holidayReq : HolidayReqs) {
                if (holidayReq.getId().equals(tempID) && holidayReq.getCheck() == -1) {
                    for (int j = 0; j < holidayReq.toString().length() + 5; j++) {
                        System.out.print('*');
                    }
                    System.out.println();
                    System.out.println((i + 1) + ": " + holidayReq);
                    for (int j = 0; j < holidayReq.toString().length() + 5; j++) {
                        System.out.print('*');
                    }
                    System.out.println();
                    i++;
                    tempLed.add(holidayReq);
                    found = true;
                }
            }
            if (found) {
                ind = -1;
                while (!correct) {
                    System.out.println("******************************************");
                    System.out.print("* Requist Number: ");
                    try {
                        ind = Main.input.nextInt();
                    } catch (InputMismatchException e) {
                        ind = -1;
                    }

                    Main.input.nextLine();
                    if (ind - 1 < 0 && ind - 1 > tempLed.size() - 1) {
                        System.out.println("******************************************");
                        System.out.println("*           Requsit not found            *");
                        System.out.println("******************************************");

                    } else {
                        correct = true;
                    }
                }
                tempLed.get(ind - 1).setCheck(0);
                find(tempID).holidayCount--;
                write();
                writeHolidays();
                System.out.println("******************************************");
                System.out.println("*           Requests Rejected            *");
                System.out.println("******************************************");
            } else {
                System.out.println("******************************************");
                System.out.println("* This employee has no pending holiday requests.  *");
                System.out.println("******************************************");
            }

        } else {
            System.out.println("******************************************");
            System.out.println("*       No Holiday Requests Found        *");
            System.out.println("******************************************");
        }
    }

    /********************************************************************************************* */
    @Override
    public void deactivateAndActivate() {
        Main.repeat = true;
        System.out.println("*   | Deactivate & Activate Managers |   *");
        System.out.println("******************************************");
        System.out.println("* 1- Activate.                           *");
        System.out.println("* 2- Deactivate.                         *");
        System.out.println("* 3- Exit.                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        ;
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                System.out.println("*          | Activate Manager |          *");
                System.out.println("******************************************");
                tempID = null;
                mangFound = false;
                System.out.print("* Enter ID: ");
                tempID = Main.input.nextLine();
                for (Manager manager : managers) {
                    if (tempID.equals(manager.getId())) {
                        manager.setStatus(true);
                        write();
                        System.out.println("******************************************");
                        System.out.println("*     the account has been activated     *");
                        System.out.println("******************************************");
                        mangFound = true;
                        break;
                    }
                }
                if (!mangFound) {
                    System.out.println("******************************************");
                    System.out.println("*           Manager NOT FOUND!!          *");
                    System.out.println("******************************************");
                }
                break;
            case 2:
                Main.choice = -1;
                System.out.println("*          | Deactivate Manager |        *");
                System.out.println("******************************************");
                mangFound = false;
                tempID = null;
                System.out.print("* Enter ID: ");
                tempID = Main.input.nextLine();
                System.out.println("******************************************");
                for (Manager manager : managers) {
                    if (tempID.equals(manager.getId())) {
                        manager.setStatus(false);
                        write();
                        System.out.println("******************************************");
                        System.out.println("*      The account has been disabled     *");
                        System.out.println("******************************************");
                        mangFound = true;
                        break;
                    }
                }
                if (!mangFound) {
                    System.out.println("******************************************");
                    System.out.println("*           Manager NOT FOUND!!          *");
                    System.out.println("******************************************");
                }
                break;
            case 3:
                Main.choice = -1;
                Main.repeat = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }

    }

    /********************************************************************************************* */
    public static void readHolidays() {
        try {
            Main.ois = new ObjectInputStream(new FileInputStream(holidays));
            HolidayReqs = (ArrayList<HolidayReq>) Main.ois.readObject();
            Main.ois.close();
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
        }
    }

    /********************************************************************************************* */
    public static void writeHolidays() {
        try {

            Main.oos = new ObjectOutputStream(new FileOutputStream(holidays));
            Main.oos.writeObject(HolidayReqs);
            Main.oos.close();

        } catch (IOException e) {
        }
    }

    /********************************************************************************************* */
    public static boolean isIdTaken(String id) {
        read();
        Manager.read();
        for (Manager manager : managers) {
            if (manager.getId().equals(id)) {
                return true;
            }
        }
        for (Employee employee : Manager.employees) {
            if (employee.getId().equals(id)) {
                return true;
            }
        }
        return false;
    }
    /************************************************************************************************ */
    public static Person find(String id){
        for (Manager manager : managers) {
            if(manager.getId().equals(id)){
                return manager;
            }
        }
        for (Employee employee : Manager.employees) {
            if(employee.getId().equals(id)){
                return employee;
            }
            
        }
        return null;
    }

}
