import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    /*********************************************************************** */
    static Scanner input = new Scanner(System.in);
    static String[] adminInfo = new String[3];
    static boolean repeat = true, in = false;
    static File admin = new File("Admin.txt");
    static int choice;
    static String temp[] = new String[2];
    static Manager currentMan;
    static Employee currntEmp;
    static Admin currAdm;
    static int c = 128_178, d = 128_310;
    static ObjectOutputStream oos;
    static ObjectInputStream ois;
    static PrintWriter w;

    /*********************************************************************** */
    public static void main(String[] args) throws IOException {
        checkFiles();
        isThereAnAdmin();
        while (repeat) {
            loginScreen();
        }

    }

    /*********************************************************************** */
    public static void loginScreen() {
        repeat = true;
        System.out.println("************************************");
        System.out.println("*         | Login Screen |         *");
        System.out.println("************************************");
        System.out.println("* 1- Login as Admin.               *");
        System.out.println("* 2- Login as Manager.             *");
        System.out.println("* 3- Login as Employee.            *");
        System.out.println("* 4- About System.                 *");
        System.out.println("* 5- Exit                          *");
        System.out.println("************************************");
        System.out.print("* Enter:");
        input();
        System.out.println("************************************");
        switch (choice) {
            case 1:
                choice = -1;
                adminLogin();
                break;
            case 2:
                choice = -1;
                managerLogin();
                break;
            case 3:
                choice = -1;
                employeeLogin();
                break;
            case 4:
                choice = -1;
                aboutProgram();
                break;
            case 5:
                choice = -1;
                repeat = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }
    }

    /****************************************************************************** */
    public static void isThereAnAdmin() {
        Admin.read();
        Admin.readHolidays();
        try {
            Scanner in = new Scanner(admin);
            if (!in.hasNext()) {
                newAdmin();
            } else {
                adminInfo = in.nextLine().split(":");
                in.close();
            }
        } catch (FileNotFoundException e) {
        }
    }

    /************************************************************************************ */
    public static void newAdmin() {
        System.out.println(">>>>> New Admin <<<<<");
        System.out.print("Enter ID: ");
        adminInfo[0] = input.nextLine();
        System.out.print("Enter Username: ");
        adminInfo[1] = input.nextLine();
        System.out.print("Enter Password: ");
        adminInfo[2] = input.nextLine();
        writeAdminInfo();
    }

    /******************************************************************************************* */
    public static void writeAdminInfo() {
        try {
            w = new PrintWriter(admin);
            w.print(adminInfo[0] + ":" + adminInfo[1] + ":" + adminInfo[2]);
            w.close();
        } catch (FileNotFoundException e) {
        }
    }

    /********************************************************************************************* */
    public static void adminLogin() {
        while (!in) {
            System.out.println("*        | Login as Admin |        *");
            System.out.println("************************************");
            System.out.print("* Admin Username: ");
            temp[0] = input.nextLine();
            System.out.print("* Admin Password: ");
            temp[1] = input.nextLine();
            if (temp[0].equals(adminInfo[1]) && temp[1].equals(adminInfo[2])) {
                currAdm = new Admin();
                in = true;
            } else {
                System.out.println("************************************");
                System.out.println("*   !Wrong Username or Password!   *");
                System.out.println("************************************");
            }
        }
        in = false;
        if (currAdm != null) {
            repeat = true;
            System.out.println("************************************");
            while (repeat) {
                currAdm.adminInterfaces();
            }
            repeat = true;
        }

    }

    /****************************************************************************************************** */
    public static void managerLogin() {
        while (!in) {
            System.out.println("*       | Login as Manager |       *");
            System.out.println("************************************");
            System.out.print("* Manager Username: ");
            temp[0] = input.nextLine();
            System.out.print("* Manager Password: ");
            temp[1] = input.nextLine();
            for (Manager manager : Admin.managers) {
                if (temp[0].equals(manager.getName()) && temp[1].equals(manager.getPassword())) {

                    currentMan = manager;
                    in = true;
                    break;

                }
            }
            if (currentMan != null) {
                System.out.println(currentMan.getStatus());
                if (currentMan.getStatus()) {
                    repeat = true;
                    System.out.println("************************************");
                    while (repeat) {
                        currentMan.managerInterFace();
                    }
                    repeat = true;
                } else {
                    System.out.println("***********************************");
                    System.out.println("*   ! The Account is disabled !   *");
                }

            } else {
                System.out.println("************************************");
                System.out.println("*   !Wrong Username or Password!   *");
                System.out.println("************************************");
            }
        }
        in = false;
    }

    /******************************************************************************************************** */
    public static void employeeLogin() {
        repeat = true;
        temp = new String[2];
        Manager.read();
        while (!in) {
            System.out.println("*       | Login as Employee |       *");
            System.out.println("************************************");
            System.out.print("* Employee Username: ");
            temp[0] = input.nextLine();
            System.out.print("* Employee Password: ");
            temp[1] = input.nextLine();
            for (Employee employee : Manager.employees) {
                if (temp[0].equals(employee.getName()) && temp[1].equals(employee.getPassword())) {
                    currntEmp = employee;
                    in = true;
                    break;
                }
            }
            if (currntEmp != null) {
                if (currntEmp.getStatus()) {
                    repeat = true;
                    System.out.println("************************************");
                    while (repeat) {
                        currntEmp.employeeInterface();
                    }
                    repeat = true;
                } else {
                    System.out.println("***********************************");
                    System.out.println("*   ! The Account is disabled !   *");
                    System.out.println("***********************************");
                }

            } else {
                System.out.println("************************************");
                System.out.println("*   !Wrong Username or Password!   *");
                System.out.println("************************************");
            }
        }
        in = false;
    }

    /*************************************************************************************************************** */
    public static void aboutProgram() {
        System.out.println("*          | System Information |          *");
        System.out.println("********************************************");
        System.out.println("* -Copmany Management System               *");
        System.out.println("* -OOP Course Project - CSE 2026           *");
        System.out.println("* -Palestine Technical College             *");
        System.out.println("* -Team Members:                           *");
        System.out.println("* Obaida Al-Banna                          *");
        System.out.println("* Emad Shurrab                             *");
        System.out.println("* Diaa Al-Ataar                            *");
        System.out.println("* Mohie-Eldeen Abu-Al-Rums                 *");
    }

    /**************************************************************************************************************** */
    public static void input() {
        try {
            choice = input.nextInt();
        } catch (InputMismatchException e) {
            choice = -1;
        }
        input.nextLine();
    }

    /******************************************************************************************************************* */
    public static void checkFiles() throws IOException {
        if (!admin.exists()) {
            admin.createNewFile();
        }
        if (!Admin.managerData.exists()) {
            Admin.managerData.createNewFile();
        }
        if (!Manager.employeeData.exists()) {
            Manager.employeeData.createNewFile();
        }
        if (!Admin.holidays.exists()) {
            Admin.holidays.createNewFile();
        }
    }

}

