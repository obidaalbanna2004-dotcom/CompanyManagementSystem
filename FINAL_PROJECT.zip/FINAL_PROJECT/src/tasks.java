import java.io.IOException;

public interface tasks {
    public void addSomeone();
    public void updateSomeone();
    public void deleteSomeone() throws IOException;
    public void searchSomeone();
    public void reportAboutSomeone();
    public void reportAll();
    public void deactivateAndActivate();
}
