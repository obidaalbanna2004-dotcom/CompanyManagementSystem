import java.io.Serializable;

public class Person implements Serializable {
    private String id;
    private String Name;
    private String Password;
    private String phoneNumber;
    private String email;
    private boolean status;
    private String timeOfAttendance, timeOfDeparture;
    int holidayCount=0,maxHolidays=2;
    String holId, holName, holReason, holDetails, holDate;
    boolean found;
    

    Person(String id, String Name, String Password, String phoneNumber, String email, boolean status) {
        this.id = id;
        this.Name = Name;
        this.Password = Password;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return Name;
    }

    public String getPassword() {
        return Password;
    }

    public boolean getStatus() {
        return status;
    }

    public String getStatus1() {
        return status ? "Active" : "Disabled";
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getTimeOfAttendance() {
        return timeOfAttendance;
    }

    public String getTimeOfDeparture() {
        return timeOfDeparture;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setTimeOfAttendance(String timeOfAttendance) {
        this.timeOfAttendance = timeOfAttendance;
    }

    public void setTimeOfDeparture(String timeOfDeparture) {
        this.timeOfDeparture = timeOfDeparture;
    }

      /********************************************************************************************************************* */
      public void Holiday() {
        Main.repeat = true;
        System.out.println("*               | Holiday |              *");
        System.out.println("******************************************");
        System.out.println("* 1- My Holidays.                        *");
        System.out.println("* 2- Creat Holiday.                      *");
        System.out.println("* 3- Exit.                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                displayHolidays();
                break;
            case 2:
            if(holidayCount<maxHolidays){
                Main.choice = -1;
//                System.out.println(holidayCount+"");
                creatHolidays();
            }else{
                System.out.println("* You can not apllay for more holidays   *");
                System.out.println("******************************************");
            }
               
                break;
            case 3:
                Main.choice = -1;
                Main.repeat = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }

    }

    /**************************************************************************************************************************** */
    public void displayHolidays() {
        Admin.readHolidays();
        found = false;
        System.out.println("*            | My Holidays |             *");
        for (HolidayReq holidayReq : Admin.HolidayReqs) {
            if (holidayReq.getId().equals(this.getId())) {
                found = true;
                for (int i = 0; i < holidayReq.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println("* " + holidayReq + "  *");
                for (int i = 0; i < holidayReq.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
            }

        }
        if (!found) {
            System.out.println("******************************************");
            System.out.println("*      You have no holiday requests      *");
            System.out.println("******************************************");
        }
    }

    /************************************************************************************************************************************ */
    public void creatHolidays() {
        System.out.println("*           | Creat a holiday |          *");
        System.out.println("******************************************");
        System.out.println("* Employee Name: "+this.getName());
        holName = this.getName();
        System.out.println("******************************************");
        System.out.print("* Enter a reason: ");
        holReason = Main.input.nextLine();
        System.out.println("******************************************");
        System.out.print("* Enter details: ");
        holDetails = Main.input.nextLine();
        System.out.println("******************************************");
        System.out.print("* Enter a date: ");

        do {
            holDate = Main.input.nextLine();
        } while (holDate.trim().isEmpty());

        System.out.println("******************************************");
        Admin.HolidayReqs.add(new HolidayReq(this.getId(), holName, holReason, holDetails, holDate));
        Admin.writeHolidays();
        holidayCount++;
        Admin.write();
        System.out.println("******************************************");
        System.out.println("*       Holiday Added Successfully       *");
        System.out.println("******************************************");
    }

    /************************************************************************************************************************************** */

    @Override
    public String toString() {
        return "ID: " + id + " || Name: " + Name + " || Password: " + Password + " || Phone Number: " + phoneNumber
                + " || Email: " + email + " || Status: " + (status ? "Active" : "Disabled") + " || Check in: "
                + (timeOfAttendance == null ? "Didn't check in" : timeOfAttendance) + " || Check out: "
                + (timeOfDeparture == null ? "Didn't check out" : timeOfDeparture);
    }
    public String searchPerson(){
        return "Nme: "+this.Name+" || "+"Status: "+(status ? "Active" : "Disabled");
    }
}
