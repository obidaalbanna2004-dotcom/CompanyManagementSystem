import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class Manager extends Person implements tasks {
    /********************************************************************************************* */
    static ArrayList<Employee> employees = new ArrayList<Employee>();
    static File employeeData = new File("Employees.data");
    String empId, empName, empPassword, empPhoneNumber, empEmail;
    int empType = -1, empStatus = -1;
    boolean status;
    String tempID, str;
    int holidayCount=0;
    /********************************************************************************************* */
    Manager(String id, String Name, String Password, String phoneNumber, String email, boolean status) {
        super(id, Name, Password, phoneNumber, email, status);
    }

    /********************************************************************************************* */
    public void managerInterFace() {
        Main.repeat = true;
        read();
        System.out.println("*               | Manager |              *");
        System.out.println("******************************************");
        System.out.println("* 1- Add Employee.                       *");
        System.out.println("* 2- Update Password Employee.                    *");
        System.out.println("* 3- Delete Employee.                    *");
        System.out.println("* 4- Search About Employee.              *");
        System.out.println("* 5- Report About Employee.              *");
        System.out.println("* 6- Report About All Employees.         *");
        System.out.println("* 7- Deactivate & Activate Employee.     *");
        System.out.println("* 8- Promote an Employee.                *");
        System.out.println("* 9- Attendance.                         *");
        System.out.println("* 10- Holiday.                           *");
        System.out.println("* 11- Exit                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                addSomeone();
                break;
            case 2:
                Main.choice = -1;
                updateSomeone();
                break;
            case 3:
                Main.choice = -1;
                deleteSomeone();
                break;
            case 4:
                Main.choice = -1;
                searchSomeone();
                break;
            case 5:
                Main.choice = -1;
                reportAboutSomeone();
                break;
            case 6:
                Main.choice = -1;
                reportAll();
                break;
            case 7:
                Main.choice = -1;
                Main.repeat = true;
                while (Main.repeat) {
                    deactivateAndActivate();
                }
                Main.repeat = true;
                break;
            case 8:
                Main.choice = -1;
                promoteEmployee();
                break;
            case 9:
                Main.choice = -1;
                Main.repeat = true;
                while (Main.repeat) {
                    attendance();
                }
                Main.repeat = true;
                break;
            case 10:
                Main.choice = -1;
                Main.repeat = true;
                while (Main.repeat) {
                    Holiday();
                }
                Main.repeat = true;
                break;
            case 11:
                Main.choice = -1;
                Main.repeat = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }

    }

    /********************************************************************************************* */
    @Override
    public void addSomeone() {
        empType = -1;
        empStatus = -1;

        System.out.println("*                  | Add Employee |                  *");
        System.out.println("******************************************************");
        System.out.print("* Enter ID: ");
        empId = Main.input.nextLine();
        while (Admin.isIdTaken(empId)) {
            System.out.println("******************************************************");
            System.out.print("* This ID is taken try anthor one: ");
            empId = Main.input.nextLine();
        }
        System.out.println("******************************************************");
        System.out.print("* Enter Name: ");
        empName = Main.input.nextLine();
        System.out.println("******************************************************");
        System.out.print("* Enter Password: ");
        empPassword = Main.input.nextLine();
        System.out.println("******************************************************");
        System.out.print("* Enter Email: ");
        empEmail = Main.input.nextLine();
        System.out.println("******************************************************");
        System.out.print("* Enter a phone number: ");
        empPhoneNumber = Main.input.nextLine();
        System.out.println("******************************************************");
        System.out.println("* Type of Employee (1-->Full-Time) or(2-->Part-Time) *");
        System.out.println("******************************************************");
        while (empType != 1 && empType != 2) {
            System.out.print("* Enter: ");
            try {
                empType = Main.input.nextInt();
            } catch (InputMismatchException e) {
                Main.input.nextLine();
            }
            if (empType != 1 && empType != 2) {
                System.out.println("************************************");
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
            }
        }
        System.out.println("******************************************************");
        Main.input.nextLine();
        empStatus = -1;
        while (empStatus != 0 && empStatus != 1) {
            System.out.print("* Enter Employee Status: ");
            try {
                empStatus = Main.input.nextInt();
            } catch (InputMismatchException e) {

            }
            if (empStatus != 0 && empStatus != 1) {
                System.out.println("************************************");
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
            }
            Main.input.nextLine();
        }
        System.out.println("******************************************************");
        /********************************************************************************************* */
        switch (empStatus) {
            case 1:
                status = true;
                employees.add(new Employee(empId, empName, empPassword, empPhoneNumber, empEmail, status, empType));
                System.out.println("******************************************");
                System.out.println("*        Employee have been Added        *");
                System.out.println("******************************************");
                write();
                break;
            case 0:
                status = false;
                employees.add(new Employee(empId, empName, empPassword, empPhoneNumber, empEmail, status, empType));
                System.out.println("******************************************");
                System.out.println("*        Employee have been Added        *");
                System.out.println("******************************************");
                write();
                break;
            default:
                System.out.println("******************************************");
                System.out.println("*              Invalid input             *");
                System.out.println("******************************************");
                break;
        }

    }

    /********************************************************************************************* */
    @Override
    public void updateSomeone() {

        found = false;

        System.out.println("*          | Update Password Employee |           *");
        System.out.println("******************************************");
        System.out.print("* Enter ID: ");
        tempID = Main.input.nextLine();
        for (Employee employee : employees) {
            if (tempID.equals(employee.getId())) {
                System.out.print("* Enter a new password: ");
                employee.setPassword(Main.input.nextLine());
                found = true;
                break;
            }
        }
        if (found) {
            System.out.println("******************************************");
            System.out.println("*          Changed Successfully          *");
            System.out.println("******************************************");
        } else {
            System.out.println("******************************************");
            System.out.println("*          Employee NOT FOUND!!          *");
            System.out.println("******************************************");
        }

    }

    /******************************************************************************************************* */
    @Override
    public void deleteSomeone() {
        tempID = null;
        found = false;
        System.out.println("*           | Delete Employee |          *");
        System.out.println("******************************************");
        System.out.print("* Enter ID: ");
        tempID = Main.input.nextLine();
        for (Employee employee : employees) {
            if (tempID.equals(employee.getId())) {
                employees.remove(employee);
                found = true;
                break;
            }
        }
        if (found) {
            write();
            System.out.println("******************************************");
            System.out.println("*          Deleted Successfully          *");
            System.out.println("******************************************");
        } else {
            System.out.println("******************************************");
            System.out.println("*          Employee NOT FOUND!!          *");
            System.out.println("******************************************");
        }

    }

    /******************************************************************************************************* */
    @Override
    public void searchSomeone() {
        tempID = null;
        found = false;
        System.out.println("*           | Search Employee |          *");
        System.out.println("******************************************");
        System.out.print("* Enter ID: ");
        tempID = Main.input.nextLine();
        for (Employee employee : employees) {
            if (tempID.equals(employee.getId())) {
                str = "* "+employee.searchPerson()+"  *";
                for (int i = 0; i < str.length(); i++) {
                    System.out.print('*');
                }
                System.out.println();

                System.out.println(str);
                for (int i = 0; i < str.length(); i++) {
                    System.out.print('*');
                }
                System.out.println();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("******************************************");
            System.out.println("*          Employee NOT FOUND!           *");
            System.out.println("******************************************");
        }

    }

    /******************************************************************************************************* */
    @Override
    public void reportAboutSomeone() {
        System.out.println("*      | Report about an Employee |      *");
        System.out.println("******************************************");
        tempID = null;
        found = false;
        System.out.print("Enter ID or Name: ");
        tempID = Main.input.nextLine();
        for (Employee employee : employees) {
            if (tempID.equals(employee.getId()) || tempID.equals(employee.getName())) {
                for (int i = 0; i < employee.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println("* " + employee + "  *");
                for (int i = 0; i < employee.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                found = true;
            }
        }
        if (!found) {
            System.out.println("******************************************");
            System.out.println("*          Employee NOT FOUND!!          *");
            System.out.println("******************************************");
        }

    }

    /******************************************************************************************************* */
    @Override
    public void reportAll() {
        if (employees.size() > 0) {
            for (Employee employee : employees) {
                for (int i = 0; i < employee.toString().length() + 5; i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println("* " + employee + "  *");
            }
            for (int i = 0; i < employees.get(employees.size() - 1).toString().length() + 5; i++) {
                System.out.print('*');
            }
            System.out.println();
        } else {
            System.out.println("******************************************");
            System.out.println("*           No Employees Found           *");
            System.out.println("******************************************");
        }

    }

    /******************************************************************************************************* */
    @Override
    public void deactivateAndActivate() {
        Main.repeat = true;
        System.out.println("*   | Deactivate & Activate Employee |   *");
        System.out.println("******************************************");
        System.out.println("* 1- Activate.                           *");
        System.out.println("* 2- Deactivate.                         *");
        System.out.println("* 3- Exit.                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                System.out.println("*         | Activate Employee |          *");
                System.out.println("******************************************");
                String tempID;
                boolean found = false;
                System.out.print("* Enter ID: ");
                tempID = Main.input.nextLine();
                System.out.println("******************************************");
                for (Employee employee : employees) {
                    if (tempID.equals(employee.getId())) {
                        employee.setStatus(true);
                        write();
                        System.out.println("******************************************");
                        System.out.println("*     The account has been activated     *");
                        System.out.println("******************************************");
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("******************************************");
                    System.out.println("*          Employee NOT FOUND!!          *");
                    System.out.println("******************************************");
                }

                break;
            case 2:
                Main.choice = -1;
                System.out.println("*        | Deactivate Employee |         *");
                System.out.println("******************************************");
                found = false;
                tempID = null;
                System.out.print("* Enter ID: ");
                tempID = Main.input.nextLine();
                System.out.println("******************************************");
                for (Employee employee : employees) {
                    if (tempID.equals(employee.getId())) {
                        employee.setStatus(false);
                        write();
                        System.out.println("******************************************");
                        System.out.println("*     The account has been disabled      *");
                        System.out.println("******************************************");
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    System.out.println("******************************************");
                    System.out.println("*          Employee NOT FOUND!!          *");
                    System.out.println("******************************************");
                }
                break;
            case 3:
                Main.choice = -1;
                Main.repeat = false;
                break;

            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }
    }

    /************************************************************************************************** */
    public void promoteEmployee() {
        str = null;
        tempID = null;
        found = false;
        System.out.println("*   | Promote an Employee to Manager |   *");
        System.out.println("******************************************");
        System.out.print("* Enter ID: ");
        tempID = Main.input.nextLine();
        for (Employee employee : employees) {
            if (tempID.equals(employee.getId())) {
                Admin.managers.add(new Manager(employee.getId(), employee.getName(), employee.getPassword(),
                        employee.getPhoneNumber(), employee.getEmail(), employee.getStatus()));
                str = "* The emloyee ( " + employee.getId() + " )has the authority of a manager.    *";
                for (int i = 0; i < str.length(); i++) {
                    System.out.print('*');
                }
                System.out.println();
                System.out.println(str);
                for (int i = 0; i < str.length(); i++) {
                    System.out.print('*');
                }
                System.out.println();
                employees.remove(employee);
                Manager.write();
                Admin.write();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("******************************************");
            System.out.println("*          Employee NOT FOUND!!          *");
            System.out.println("******************************************");
        }

    }

    /******************************************************************************************************************* */
    public void attendance() {
        Main.repeat = true;
        System.out.println("*             | Attendance |             *");
        System.out.println("******************************************");
        System.out.println("* 1- Time of attendance.                 *");
        System.out.println("* 2- ATime of departure.                 *");
        System.out.println("* 3- Exit.                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                System.out.println("*         | Time of attendance |         *");
                System.out.println("******************************************");
                System.out.print("* Enter Time: ");
                super.setTimeOfAttendance(Main.input.nextLine());
                Admin.write();
                System.out.println("******************************************");
                System.out.println("*    Time of Attenddance has been set    *");
                System.out.println("******************************************");
                break;
            case 2:
                Main.choice = -1;
                System.out.println("*         | Time of departure |          *");
                System.out.println("******************************************");
                System.out.print("* Enter Time: ");
                setTimeOfDeparture(Main.input.nextLine());
                Admin.write();
                System.out.println("******************************************");
                System.out.println("*     Time of Departure has been set     *");
                System.out.println("******************************************");
                break;
            case 3:
                Main.choice = -1;
                Main.repeat = false;
                break;
        }

    }

  
    public static void read() {
        try {
            Main.ois = new ObjectInputStream(new FileInputStream(employeeData));
            employees = (ArrayList<Employee>) Main.ois.readObject();
            Main.ois.close();

        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
        }
    }

    /************************************************************************************************************ */
    public static void write() {
        try {
                Main.oos = new ObjectOutputStream(new FileOutputStream(employeeData));
                Main.oos.writeObject(employees);
                Main.oos.close();
            
        } catch (IOException e) {
        }
    }

}
