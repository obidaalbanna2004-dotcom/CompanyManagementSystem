import java.io.Serializable;

public class HolidayReq implements Serializable{
    String id;
    String name;
    String reason;
    String details;
    String date;
    int check;

    HolidayReq(String id, String name, String reason, String details, String date) {
        this.id = id;
        this.name = name;
        this.reason = reason;
        this.details = details;
        this.date = date;
        check = -1;
    }

    @Override
    public String toString() {
        String check= "No Response";
        switch (this.check) {
            case 1:
            check = "Accepted";
                break;
            case 0:
            check = "Rejected";
                break;
        }
        return "ID: " + id + " || " + "Name: " + name + " || " + "Reason: " + reason + " || " + "Details: " + details
                + " || " + "Date: " + date + " || " + "Check: " + check;
    }

    public String getId() {
        return id;
    }
    public int getCheck() {
        return check;
    }
    public void setCheck(int check) {
        this.check = check;
    }

}
