
public class Employee extends Person {
    /********************************************************************* */
    String typeOfEmployee;
    boolean attend;

    /********************************************************************** */

    Employee(String id, String Name, String Password, String phoneNumber, String email, boolean status,
            int typeOfEmployee) {
        super(id, Name, Password, phoneNumber, email, status);
        switch (typeOfEmployee) {
            case 1:
                this.typeOfEmployee = "Full-Time";
                break;
            case 2:
                this.typeOfEmployee = "Part-Time";

                break;
        }
    }

    /************************************************************************************************* */
    public void employeeInterface() {
        Main.repeat = true;
        System.out.println("*                Employee                *");
        System.out.println("******************************************");
        System.out.println("* 1- Change Password.                    *");
        System.out.println("* 2- Attendance.                         *");
        System.out.println("* 3- Holiday.                            *");
        System.out.println("* 4- Exit.                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                changePassword();
                break;
            case 2:
                Main.choice = -1;
                attend = true;
                while (attend) {
                    attendance();
                }
                Main.repeat = true;

                break;
            case 3:
                Main.choice = -1;
                Main.repeat = true;
                while (Main.repeat) {
                    Holiday();
                }
                Main.repeat = true;

                break;
            case 4:
                Main.choice = -1;
                Main.repeat = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;

        }
    }

    /********************************************************************************************************* */
    public void changePassword() {
        System.out.println("*           | Change Password |           ");
        System.out.println("******************************************");
        System.out.print("* Enter new Password: ");
        this.setPassword(Main.input.nextLine());
        Manager.write();
        System.out.println("******************************************");
        System.out.println("*       Password changed succfully       *");
        System.out.println("******************************************");
    }

    /************************************************************************************************************* */
    public void attendance() {
        System.out.println("*             | Attendance |             *");
        System.out.println("******************************************");
        System.out.println("* 1- Time of attendance.                 *");
        System.out.println("* 2- ATime of  departure.                *");
        System.out.println("* 3- Exit.                               *");
        System.out.println("******************************************");
        System.out.print("* Enter: ");
        Main.input();
        System.out.println("******************************************");
        switch (Main.choice) {
            case 1:
                Main.choice = -1;
                System.out.println("*         | Time of attendance |          ");
                System.out.println("******************************************");
                System.out.print("* Enter Time: ");
                super.setTimeOfAttendance(Main.input.nextLine());
                Manager.write();
                System.out.println("******************************************");
                System.out.println("*    Time of Attenddance has been set    *");
                System.out.println("******************************************");
                break;
            case 2:
                Main.choice = -1;
                System.out.println("*         | Time of departure |           ");
                System.out.println("******************************************");
                System.out.print("* Enter Time: ");
                setTimeOfDeparture(Main.input.nextLine());
                Manager.write();
                System.out.println("******************************************");
                System.out.println("*     Time of Departure has been set     *");
                System.out.println("******************************************");
                break;
            case 3:
                Main.choice = -1;
                attend = false;
                break;
            default:
                System.out.println("*           Invalid Input          *");
                System.out.println("************************************");
                break;
        }

    }

    @Override
    public String toString() {
        return super.toString() + " || Type of Employee: " + typeOfEmployee;
    }

}
